package com.bitc.team2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AndroidTeamProjectTeam6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
